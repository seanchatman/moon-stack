Hey, thanks for wanting to contribute to baseimage-docker. :)

If you have a question, please use the [discussion forum](https://groups.google.com/d/forum/passenger-docker). The Github issue tracker is only for **bug reports and feature requests**.

If you want to develop baseimage-docker, use the Vagrantfile in the repository. It will setup an Ubuntu VM with Docker installed in it. Use the Makefile to build the image.
